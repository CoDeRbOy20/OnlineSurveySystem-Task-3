package model;

public enum QuestionType {
    MULTIPLE_CHOICE,
    TEXT_INPUT,
    RATING_SCALE
}
