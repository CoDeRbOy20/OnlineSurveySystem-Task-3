package model;

public enum UserRole {
    ADMIN,
    USER
}